create view prerecord_view as
  select
    `prescription_view`.`prescriptionid` AS `prescriptionid`,
    `hospital`.`register`.`patientname`  AS `patientname`,
    `hospital`.`department`.`name`       AS `departname`,
    `hospital`.`doctor`.`name`           AS `doctorname`,
    `prescription_view`.`name`           AS `name`,
    `prescription_view`.`unitname`       AS `unitname`,
    `prescription_view`.`outprice`       AS `outprice`,
    `prescription_view`.`number`         AS `number`,
    `prescription_view`.`feetypename`    AS `feetypename`,
    `hospital`.`register`.`date`         AS `date`
  from (((`hospital`.`register`
    join `hospital`.`prescription_view`) join `hospital`.`department`) join `hospital`.`doctor`)
  where ((`prescription_view`.`prescriptionid` = `hospital`.`register`.`id`) and
         (`hospital`.`register`.`departmentId` = `hospital`.`department`.`id`) and
         (`hospital`.`register`.`doctorId` = `hospital`.`doctor`.`id`));

