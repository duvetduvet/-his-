create view doctor_view as
  select
    `hospital`.`doctor`.`id`       AS `id`,
    `hospital`.`doctor`.`name`     AS `drname`,
    `hospital`.`doctor`.`sex`      AS `sex`,
    `hospital`.`doctor`.`birth`    AS `birth`,
    `hospital`.`doctor`.`identity` AS `identity`,
    `hospital`.`doctor`.`phone`    AS `phone`,
    `hospital`.`doctor`.`address`  AS `address`,
    `hospital`.`department`.`name` AS `departname`
  from (`hospital`.`doctor`
    join `hospital`.`department`)
  where (`hospital`.`doctor`.`departmentId` = `hospital`.`department`.`id`);

