create view stockrecord_view as
  select
    `hospital`.`stockrecord`.`id`         AS `id`,
    `hospital`.`stockrecord`.`medicineId` AS `medicineId`,
    `medicine_view`.`name`                AS `medicinename`,
    `medicine_view`.`unitname`            AS `unitname`,
    `medicine_view`.`inprice`             AS `inprice`,
    `medicine_view`.`outprice`            AS `outprice`,
    `medicine_view`.`feetypename`         AS `feetypename`,
    `medicine_view`.`factoryname`         AS `factoryname`,
    `medicine_view`.`stock`               AS `stock`,
    `medicine_view`.`warn`                AS `warn`,
    `hospital`.`stockrecord`.`number`     AS `number`,
    `hospital`.`stockrecord`.`usefulDate` AS `usefuldate`,
    `hospital`.`position`.`name`          AS `positionname`,
    `hospital`.`stockrecord`.`date`       AS `date`
  from ((`hospital`.`stockrecord`
    join `hospital`.`medicine_view`) join `hospital`.`position`)
  where ((`hospital`.`stockrecord`.`medicineId` = `medicine_view`.`id`) and
         (`hospital`.`stockrecord`.`positionId` = `hospital`.`position`.`id`));

