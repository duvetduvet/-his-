create view prescription_view as
  select
    `hospital`.`prescription`.`prescriptionid` AS `prescriptionid`,
    `hospital`.`prescription`.`id`             AS `id`,
    `hospital`.`medicine`.`name`               AS `name`,
    `medcure_view`.`unitname`                  AS `unitname`,
    `medcure_view`.`outprice`                  AS `outprice`,
    `hospital`.`prescription`.`number`         AS `number`,
    `medcure_view`.`feetypename`               AS `feetypename`,
    `medcure_view`.`type`                      AS `type`
  from (((`hospital`.`prescription`
    join `hospital`.`medicine`) join `hospital`.`register`) join `hospital`.`medcure_view`)
  where ((`hospital`.`prescription`.`prescriptionid` = `hospital`.`register`.`id`) and
         (`hospital`.`prescription`.`medicineid` = `hospital`.`medicine`.`id`) and (`hospital`.`register`.`useful` = 1)
         and (`hospital`.`medicine`.`name` = `medcure_view`.`name`));

