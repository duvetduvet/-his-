create view register_view as
  select
    `hospital`.`register`.`id`          AS `id`,
    `hospital`.`register`.`patientname` AS `patientname`,
    `hospital`.`patient`.`sex`          AS `sex`,
    `hospital`.`patient`.`birth`        AS `birth`,
    `hospital`.`patient`.`identity`     AS `identity`,
    `hospital`.`department`.`name`      AS `departname`,
    `hospital`.`doctor`.`name`          AS `doctorname`,
    `hospital`.`regtype`.`name`         AS `regtypename`,
    `hospital`.`register`.`fee`         AS `fee`,
    `hospital`.`register`.`first`       AS `first`,
    `hospital`.`position`.`name`        AS `positionname`,
    `hospital`.`register`.`date`        AS `date`,
    `hospital`.`register`.`prestate`    AS `prestate`,
    `hospital`.`register`.`chargestate` AS `chargestate`,
    `hospital`.`register`.`medstate`    AS `medstate`
  from (((((`hospital`.`patient`
    join `hospital`.`doctor`) join `hospital`.`register`) join `hospital`.`department`) join `hospital`.`regtype`) join
    `hospital`.`position`)
  where ((`hospital`.`register`.`patientname` = `hospital`.`patient`.`name`) and
         (`hospital`.`regtype`.`id` = `hospital`.`register`.`regtypeid`) and
         (`hospital`.`register`.`departmentId` = `hospital`.`department`.`id`) and
         (`hospital`.`register`.`doctorId` = `hospital`.`doctor`.`id`) and
         (`hospital`.`register`.`positionId` = `hospital`.`position`.`id`) and
         (unix_timestamp(`hospital`.`register`.`date`) >= unix_timestamp(cast(sysdate() as date))));

