create view medcure_view as
  select
    `hospital`.`medicine`.`id`       AS `id`,
    `hospital`.`medicine`.`name`     AS `name`,
    `hospital`.`unit`.`name`         AS `unitname`,
    `hospital`.`medicine`.`outprice` AS `outprice`,
    `hospital`.`feetype`.`name`      AS `feetypename`,
    `hospital`.`medicine`.`spell`    AS `spell`,
    `hospital`.`medicine`.`type`     AS `type`
  from ((`hospital`.`medicine`
    join `hospital`.`unit`) join `hospital`.`feetype`)
  where ((`hospital`.`medicine`.`unitId` = `hospital`.`unit`.`id`) and
         (`hospital`.`medicine`.`feetypeId` = `hospital`.`feetype`.`id`));

