create view medicine_view as
  select
    `hospital`.`medicine`.`id`        AS `id`,
    `hospital`.`medicine`.`name`      AS `name`,
    `hospital`.`unit`.`name`          AS `unitname`,
    `hospital`.`medicine`.`inprice`   AS `inprice`,
    `hospital`.`medicine`.`outprice`  AS `outprice`,
    `hospital`.`feetype`.`name`       AS `feetypename`,
    `hospital`.`factory`.`name`       AS `factoryname`,
    `hospital`.`medicine`.`stock`     AS `stock`,
    `hospital`.`medicine`.`warn`      AS `warn`,
    `hospital`.`medicine`.`spell`     AS `spell`,
    `hospital`.`medicine`.`truestock` AS `truestock`
  from (((`hospital`.`medicine`
    join `hospital`.`unit`) join `hospital`.`feetype`) join `hospital`.`factory`)
  where ((`hospital`.`unit`.`id` = `hospital`.`medicine`.`unitId`) and
         (`hospital`.`medicine`.`feetypeId` = `hospital`.`feetype`.`id`) and
         (`hospital`.`medicine`.`factoryId` = `hospital`.`factory`.`id`) and (`hospital`.`medicine`.`type` = '药品费'));

