create view medsoldrecord_view as
  select
    `prerecord_view`.`name`                                                                AS `name`,
    `medicine_view`.`unitname`                                                             AS `unitname`,
    `medicine_view`.`inprice`                                                              AS `inprice`,
    `medicine_view`.`outprice`                                                             AS `outprice`,
    `prerecord_view`.`number`                                                              AS `number`,
    (`medicine_view`.`inprice` * `prerecord_view`.`number`)                                AS `suminprice`,
    (`medicine_view`.`outprice` * `prerecord_view`.`number`)                               AS `sumoutprice`,
    ((`medicine_view`.`outprice` - `medicine_view`.`inprice`) * `prerecord_view`.`number`) AS `income`,
    `medicine_view`.`stock`                                                                AS `stock`,
    `prerecord_view`.`date`                                                                AS `date`
  from (`hospital`.`prerecord_view`
    join `hospital`.`medicine_view`)
  where (`prerecord_view`.`name` = `medicine_view`.`name`);

