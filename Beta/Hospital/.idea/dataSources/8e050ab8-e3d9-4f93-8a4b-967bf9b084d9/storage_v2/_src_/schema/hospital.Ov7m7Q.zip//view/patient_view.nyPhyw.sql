create view patient_view as
  select
    `hospital`.`patient`.`name`     AS `name`,
    `hospital`.`patient`.`sex`      AS `sex`,
    `hospital`.`patient`.`birth`    AS `birth`,
    `hospital`.`patient`.`identity` AS `identity`
  from `hospital`.`patient`;

