create view curesoldrecord_view as
  select
    `prerecord_view`.`name`                                 AS `name`,
    `medcure_view`.`unitname`                               AS `unitname`,
    `medcure_view`.`outprice`                               AS `outprice`,
    `prerecord_view`.`number`                               AS `number`,
    (`medcure_view`.`outprice` * `prerecord_view`.`number`) AS `sumoutprice`,
    `prerecord_view`.`date`                                 AS `date`
  from (`hospital`.`prerecord_view`
    join `hospital`.`medcure_view`)
  where ((`prerecord_view`.`name` = `medcure_view`.`name`) and (`medcure_view`.`type` = '诊疗费'));

