create view vip_view as
select `a`.`id`       AS `patientId`,
       `a`.`name`     AS `name`,
       `a`.`sex`      AS `sex`,
       `a`.`birth`    AS `birth`,
       `a`.`identity` AS `identity`,
       `a`.`phone`    AS `phone`,
       `b`.`id`       AS `id`,
       `b`.`password` AS `password`,
       `b`.`consume`  AS `consume`,
       `b`.`remain`   AS `remain`,
       `b`.`present`  AS `present`,
       `b`.`useful`   AS `useful`
from (`hospital2`.`vip` `b`
       join `hospital2`.`patient` `a` on ((`a`.`vip` = `b`.`id`)));

