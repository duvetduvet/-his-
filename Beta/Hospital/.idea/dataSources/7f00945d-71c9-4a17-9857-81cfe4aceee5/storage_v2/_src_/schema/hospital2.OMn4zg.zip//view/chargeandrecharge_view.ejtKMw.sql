create view chargeandrecharge_view as select `hospital2`.`chargerecord`.`card`      AS `card`,
                                             `vip_view`.`phone`                     AS `phone`,
                                             (`hospital2`.`chargerecord`.`remain` +
                                              `hospital2`.`chargerecord`.`present`) AS `sum`,
                                             `hospital2`.`chargerecord`.`date`      AS `date`
                                      from (`hospital2`.`chargerecord`
                                             join `hospital2`.`vip_view`)
                                      where (`hospital2`.`chargerecord`.`card` = `vip_view`.`id`)
                                      union
                                      select `hospital2`.`order`.`vipId`                                   AS `card`,
                                             `vip_view`.`phone`                                            AS `phone`,
                                             -((`hospital2`.`order`.`card` + `hospital2`.`order`.`given`)) AS `sum`,
                                             `hospital2`.`order`.`date`                                    AS `date`
                                      from (`hospital2`.`order`
                                             join `hospital2`.`vip_view`)
                                      where ((`hospital2`.`order`.`vipId` = `vip_view`.`id`) and
                                             ((`hospital2`.`order`.`card` <> 0) or (`hospital2`.`order`.`given` <> 0)));

