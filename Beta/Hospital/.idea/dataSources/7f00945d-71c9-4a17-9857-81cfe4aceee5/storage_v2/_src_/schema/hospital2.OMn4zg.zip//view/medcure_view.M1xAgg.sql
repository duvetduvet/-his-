create view medcure_view as
select `hospital2`.`medicine`.`id`                 AS `id`,
       `hospital2`.`medicine`.`name`               AS `name`,
       `hospital2`.`medicine`.`itemCode`           AS `itemCode`,
       `hospital2`.`medicine`.`itemGrade`          AS `itemGrade`,
       `hospital2`.`unit`.`name`                   AS `unitname`,
       ifnull(`hospital2`.`medicine`.`inprice`, 0) AS `inprice`,
       `hospital2`.`medicine`.`outprice`           AS `outprice`,
       ifnull(`hospital2`.`medicine`.`stock`, 0)   AS `stock`,
       `hospital2`.`feetype`.`name`                AS `feetypename`,
       `hospital2`.`medicine`.`spell`              AS `spell`,
       `hospital2`.`medicine`.`type`               AS `type`,
       `hospital2`.`medicine`.`useful`             AS `useful`,
       `hospital2`.`medicine`.`isInclude`          AS `isInclude`
from ((`hospital2`.`medicine` join `hospital2`.`unit`)
       join `hospital2`.`feetype`)
where ((`hospital2`.`medicine`.`unitId` = `hospital2`.`unit`.`id`) and
       (`hospital2`.`medicine`.`feetypeId` = `hospital2`.`feetype`.`id`));

