create view stockrecord_view as
select `hospital2`.`stockrecord`.`id`         AS `id`,
       `hospital2`.`stockrecord`.`medicineId` AS `medicineId`,
       `medicine_view`.`name`                 AS `medicinename`,
       `medicine_view`.`unitname`             AS `unitname`,
       `medicine_view`.`inprice`              AS `inprice`,
       `medicine_view`.`outprice`             AS `outprice`,
       `medicine_view`.`feetypename`          AS `feetypename`,
       `medicine_view`.`factoryname`          AS `factoryname`,
       `medicine_view`.`stock`                AS `stock`,
       `medicine_view`.`warn`                 AS `warn`,
       `hospital2`.`stockrecord`.`number`     AS `number`,
       `hospital2`.`stockrecord`.`usefulDate` AS `usefuldate`,
       `hospital2`.`position`.`name`          AS `positionname`,
       `hospital2`.`stockrecord`.`date`       AS `date`
from ((`hospital2`.`stockrecord` join `hospital2`.`medicine_view`)
       join `hospital2`.`position`)
where ((`hospital2`.`stockrecord`.`medicineId` = `medicine_view`.`id`) and
       (`hospital2`.`stockrecord`.`positionId` = `hospital2`.`position`.`id`));

