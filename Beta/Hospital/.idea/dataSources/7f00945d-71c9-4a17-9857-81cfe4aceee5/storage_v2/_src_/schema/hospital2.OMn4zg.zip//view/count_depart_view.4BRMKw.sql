create view count_depart_view as
select `temp`.`name` AS `name`,`temp`.`income` AS `sumincome`,`temp`.`feetype` AS `feetype`,`temp`.`date` AS `date`
from (select `re`.`id`         AS `id`,
             `re`.`departname` AS `name`,
             `re`.`fee`        AS `income`,
             '挂号费'             AS `medname`,
             '挂号费'             AS `feetype`,
             `re`.`date`       AS `date`
      from `hospital2`.`all_register_view` `re`
      union
      select `po`.`pid`                                                      AS `id`,
             `po`.`departname`                                               AS `name`,
             ((`pre`.`outprice` * `pre`.`number`) * `po`.`medicinediscount`) AS `income`,
             `pre`.`name`                                                    AS `medname`,
             `pre`.`feetypename`                                             AS `feetype`,
             `po`.`date`                                                     AS `date`
      from (`hospital2`.`prescription_view` `pre`
             join `hospital2`.`pre_order_view` `po`)
      where ((`po`.`pid` = `pre`.`prescriptionid`) and (`po`.`state` >= 2) and
             ((`po`.`card` = 0) or isnull(`po`.`card`)) and ((`po`.`given` = 0) or isnull(`po`.`card`)) and
             (`pre`.`type` = '药品费'))
      union
      select `po`.`pid`                                                     AS `id`,
             `po`.`departname`                                              AS `name`,
             ((`pre`.`outprice` * `pre`.`number`) * `po`.`medcurediscount`) AS `income`,
             `pre`.`name`                                                   AS `medname`,
             `pre`.`feetypename`                                            AS `feetype`,
             `po`.`date`                                                    AS `date`
      from (`hospital2`.`prescription_view` `pre`
             join `hospital2`.`pre_order_view` `po`)
      where ((`po`.`pid` = `pre`.`prescriptionid`) and (`po`.`state` >= 2) and
             ((`po`.`card` = 0) or isnull(`po`.`card`)) and ((`po`.`given` = 0) or isnull(`po`.`card`)) and
             (`pre`.`type` = '诊疗费'))) `temp`;

