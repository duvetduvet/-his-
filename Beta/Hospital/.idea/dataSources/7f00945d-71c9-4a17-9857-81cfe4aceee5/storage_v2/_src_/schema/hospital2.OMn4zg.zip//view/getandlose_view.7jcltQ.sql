create view getandlose_view as
select `hospital2`.`stockrecord`.`id`                                   AS `id`,
       `medicine_view`.`name`                                           AS `medname`,
       `medicine_view`.`unitname`                                       AS `unitname`,
       `medicine_view`.`inprice`                                        AS `inprice`,
       `hospital2`.`stockrecord`.`number`                               AS `number`,
       (`medicine_view`.`inprice` * `hospital2`.`stockrecord`.`number`) AS `profit`,
       `hospital2`.`position`.`name`                                    AS `posname`,
       `hospital2`.`stockrecord`.`date`                                 AS `date`
from (((`hospital2`.`stockrecord` join `hospital2`.`countrecord`) join `hospital2`.`position`)
       join `hospital2`.`medicine_view`)
where ((`hospital2`.`stockrecord`.`id` = `hospital2`.`countrecord`.`id`) and
       (`hospital2`.`stockrecord`.`positionId` = `hospital2`.`position`.`id`) and
       (`hospital2`.`stockrecord`.`medicineId` = `medicine_view`.`id`));

