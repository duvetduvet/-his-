create procedure firsts_secone_visit(IN start datetime, IN last datetime)
BEGIN
     (SELECT 
    a.patientid, a.patientname name, ifnull(a.s,0) first, ifnull(b.s,0) second
FROM
    (SELECT 
        patientid, patientname, COUNT(first) s
    FROM
        all_register_view
    WHERE
        (first = '是')
            AND (date BETWEEN start AND last)
    GROUP BY patientid) a
        LEFT JOIN
    (SELECT 
        patientid, patientname, COUNT(first) s
    FROM
        all_register_view
    WHERE
        (first = '否')
            AND (date BETWEEN start AND last)
    GROUP BY patientid) b ON (a.patientid = b.patientid)) UNION (SELECT 
    b.patientid, b.patientname name, ifnull(a.s,0) first, ifnull(b.s,0) second
FROM
    (SELECT 
        patientid, patientname, COUNT(first) s
    FROM
        all_register_view
    WHERE
        (first = '是')
            AND (date BETWEEN start AND last)
    GROUP BY patientid) a
        RIGHT JOIN
    (SELECT 
        patientid, patientname, COUNT(first) s
    FROM
        all_register_view
    WHERE
        (first = '否')
            AND (date BETWEEN start AND last)
    GROUP BY patientid) b ON (a.patientid = b.patientid));
END;

