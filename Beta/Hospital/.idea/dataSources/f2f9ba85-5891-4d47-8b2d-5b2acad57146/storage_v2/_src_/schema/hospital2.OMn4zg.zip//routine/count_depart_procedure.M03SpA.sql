create procedure count_depart_procedure(IN start date, IN end date)
BEGIN
SET @sql = NULL;
SELECT 
    GROUP_CONCAT(CONCAT('SUM(IF(feetype = \'',
                feetype.name,
                '\',sumincome,0)) AS \'',
                feetype.name,
                '\''))
INTO @sql FROM
    feetype;
SET @sql = CONCAT('SELECT name, ', @sql, ' FROM count_depart_view WHERE date BETWEEN \'', start,' 00:00:00\' AND \'', end,' 23:59:59\' GROUP BY name');
PREPARE statement FROM @sql;
EXECUTE statement;
DEALLOCATE PREPARE statement;
END;

