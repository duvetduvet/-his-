create view patient_view as
select `a`.`id`             AS `id`,
       `a`.`name`           AS `name`,
       `a`.`sex`            AS `sex`,
       `a`.`birth`          AS `birth`,
       `a`.`vip`            AS `vip`,
       `a`.`identity`       AS `identity`,
       `a`.`phone`          AS `phone`,
       `a`.`date`           AS `date`,
       `a`.`last`           AS `last`,
       ifnull(`c`.`sum`, 0) AS `sum`
from (((select `hospital`.`patient`.`id`       AS `id`,
               `hospital`.`patient`.`name`     AS `name`,
               `hospital`.`patient`.`sex`      AS `sex`,
               `hospital`.`patient`.`birth`    AS `birth`,
               `hospital`.`patient`.`vip`      AS `vip`,
               `hospital`.`patient`.`identity` AS `identity`,
               `hospital`.`patient`.`phone`    AS `phone`,
               `hospital`.`patient`.`date`     AS `date`,
               `hospital`.`patient`.`last`     AS `last`,
               0                               AS `sum`
        from `hospital`.`patient`)) `a`
       left join (select `b`.`patientid`                                                AS `id`,
                         `b`.`name`                                                     AS `name`,
                         `b`.`sex`                                                      AS `sex`,
                         NULL                                                           AS `birth`,
                         NULL                                                           AS `vip`,
                         NULL                                                           AS `identity`,
                         NULL                                                           AS `phone`,
                         NULL                                                           AS `date`,
                         NULL                                                           AS `last`,
                         sum((((`b`.`card` + `b`.`given`) + `b`.`cash`) + `b`.`other`)) AS `sum`
                  from `hospital`.`pre_order_view` `b`
                  where (`b`.`state` >= 2)
                  group by `b`.`patientid`) `c` on ((`c`.`id` = `a`.`id`)));

