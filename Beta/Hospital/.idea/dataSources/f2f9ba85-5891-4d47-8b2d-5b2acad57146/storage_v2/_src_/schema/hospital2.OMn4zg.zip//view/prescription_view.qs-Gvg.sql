create view prescription_view as
select `p`.`listid`                 AS `prescriptionid`,
       `p`.`medicineid`             AS `medid`,
       `p`.`medname`                AS `name`,
       `medcure_view`.`unitname`    AS `unitname`,
       `p`.`outprice`               AS `outprice`,
       `p`.`inprice`                AS `inprice`,
       `p`.`number`                 AS `number`,
       `medcure_view`.`feetypename` AS `feetypename`,
       `medcure_view`.`type`        AS `type`,
       `medcure_view`.`itemCode`    AS `itemCode`,
       `medcure_view`.`itemGrade`   AS `itemGrade`
from (`hospital2`.`prescription` `p`
       join `hospital2`.`medcure_view`)
where (`p`.`medicineid` = `medcure_view`.`id`);

