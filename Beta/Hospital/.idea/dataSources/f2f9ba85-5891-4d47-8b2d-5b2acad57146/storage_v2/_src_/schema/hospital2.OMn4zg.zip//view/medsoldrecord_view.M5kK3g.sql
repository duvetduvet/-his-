create view medsoldrecord_view as
select `pre`.`name`                                                      AS `name`,
       `pre`.`unitname`                                                  AS `unitname`,
       `pre`.`inprice`                                                   AS `inprice`,
       `pre`.`outprice`                                                  AS `outprice`,
       `pre`.`number`                                                    AS `number`,
       round((`pre`.`inprice` * `pre`.`number`), 3)                      AS `suminprice`,
       round((`pre`.`outprice` * `pre`.`number`), 3)                     AS `sumoutprice`,
       round(((`pre`.`outprice` - `pre`.`inprice`) * `pre`.`number`), 3) AS `income`,
       `po`.`date`                                                       AS `date`
from (`hospital2`.`prescription_view` `pre`
       join `hospital2`.`pre_order_view` `po`)
where ((`pre`.`prescriptionid` = `po`.`pid`) and (`po`.`state` >= 2) and (`pre`.`type` = '药品费'));

