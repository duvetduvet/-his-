create procedure patient_procedure(IN start datetime, IN last datetime)
BEGIN

SELECT 
    `a`.`id` AS `id`,
    `a`.`name` AS `name`,
    `a`.`sex` AS `sex`,
    `a`.`birth` AS `birth`,
    `a`.`vip` AS `vip`,
    `a`.`identity` AS `identity`,
    `a`.`phone` AS `phone`,
    `a`.`date` AS `date`,
    `a`.`last` AS `last`,
    ifnull( `c`.`sum`,0) as sum
FROM
    (SELECT 
        `hospital`.`patient`.`id` AS `id`,
            `hospital`.`patient`.`name` AS `name`,
            `hospital`.`patient`.`sex` AS `sex`,
            `hospital`.`patient`.`birth` AS `birth`,
            `hospital`.`patient`.`vip` AS `vip`,
            `hospital`.`patient`.`identity` AS `identity`,
            `hospital`.`patient`.`phone` AS `phone`,
            `hospital`.`patient`.`date` AS `date`,
            `hospital`.`patient`.`last` AS `last`,
            0 AS `sum`
    FROM
        `hospital`.`patient`) `a`
        LEFT JOIN
    (SELECT 
        b.`patientid` AS `id`,
            b.`name` AS `name`,
            b.`sex` AS `sex`,
            NULL AS `birth`,
            NULL AS `vip`,
            NULL AS `identity`,
            NULL AS `phone`,
            NULL AS `date`,
            NULL AS `last`,
            SUM(ifnull(b.card,0) + ifnull(b.given ,0)+ ifnull(b.cash ,0) + ifnull(b.other,0)) AS `sum`
    FROM
        pre_order_view `b`
    WHERE
        b.state >= 2 and b.regdate between start and last
    GROUP BY b.patientid) c ON c.id = a.id
    order by sum desc
    
    ;

END;

