create procedure patient_procedure(IN start datetime, IN last datetime)
BEGIN

SELECT 
    `a`.`id` AS `id`,
    `a`.`name` AS `name`,
    `a`.`sex` AS `sex`,
    `a`.`birth` AS `birth`,
    `a`.`vip` AS `vip`,
    `a`.`identity` AS `identity`,
    `a`.`phone` AS `phone`,
    `a`.`date` AS `date`,
    `a`.`last` AS `last`,
    ifnull( `c`.`sum`,0) as sum
FROM
    (SELECT 
       `patient`.`id` AS `id`,
           `patient`.`name` AS `name`,
           `patient`.`sex` AS `sex`,
           `patient`.`birth` AS `birth`,
           `patient`.`vip` AS `vip`,
           `patient`.`identity` AS `identity`,
           `patient`.`phone` AS `phone`,
           `patient`.`date` AS `date`,
           `patient`.`last` AS `last`,
            0 AS `sum`
    FROM
       `patient`) `a`
        LEFT JOIN
    (SELECT 
        b.`patientid` AS `id`,
            b.`name` AS `name`,
            b.`sex` AS `sex`,
            NULL AS `birth`,
            NULL AS `vip`,
            NULL AS `identity`,
            NULL AS `phone`,
            NULL AS `date`,
            NULL AS `last`,
            SUM(ifnull(b.card,0) + ifnull(b.given ,0)+ ifnull(b.cash ,0) + ifnull(b.other,0)) AS `sum`
    FROM
        pre_order_view `b`
    WHERE
        b.state >= 2 and b.regdate between start and last
    GROUP BY b.patientid) c ON c.id = a.id
    order by sum desc
    
    ;

END;

