create view stockrecord_view as
select `hospital2`.`stockrecord`.`id`          AS `id`,
       `hospital2`.`stockrecord`.`medname`     AS `medicinename`,
       `hospital2`.`stockrecord`.`inprice`     AS `inprice`,
       `hospital2`.`stockrecord`.`outprice`    AS `outprice`,
       `hospital2`.`stockrecord`.`feetypename` AS `feetypename`,
       `hospital2`.`stockrecord`.`factoryname` AS `factoryname`,
       `hospital2`.`stockrecord`.`number`      AS `number`,
       `hospital2`.`stockrecord`.`usefulDate`  AS `usefuldate`,
       `hospital2`.`position`.`name`           AS `positionname`,
       `hospital2`.`stockrecord`.`iscount`     AS `iscount`,
       `hospital2`.`stockrecord`.`date`        AS `date`
from (`hospital2`.`stockrecord`
       join `hospital2`.`position`)
where (`hospital2`.`stockrecord`.`positionId` = `hospital2`.`position`.`id`);

