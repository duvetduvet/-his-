create procedure count_depart_procedure(IN start date, IN end date)
label_pro: BEGIN
SET @sql = NULL;
set @s = null;
set @e = null;
set @f = null;

set @s = concat(start,' 00:00:00');
set @e = concat(end,' 23:59:59');

select distinct(feetype) name into @f from count_depart_view where date between @s and @e limit 1;

if @f is null then 
leave label_pro;
end if;

SELECT 
    GROUP_CONCAT(CONCAT('SUM(IF(feetype = \'',
                t.name,
                '\',sumincome,0)) AS \'',
                t.name,
                '\''))
INTO @sql from (select distinct(feetype) name from count_depart_view where date between @s and @e) t;


SET @sql = CONCAT('SELECT name 名称, ', @sql, ' FROM count_depart_view WHERE date BETWEEN \'', start,' 00:00:00\' AND \'', end,' 23:59:59\' GROUP BY name');
PREPARE statement FROM @sql;
EXECUTE statement;
DEALLOCATE PREPARE statement;
END;

