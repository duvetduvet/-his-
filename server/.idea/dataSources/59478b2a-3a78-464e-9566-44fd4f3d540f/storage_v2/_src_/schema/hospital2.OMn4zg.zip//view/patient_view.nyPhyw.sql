create view patient_view as
select `a`.`id`             AS `id`,
       `a`.`name`           AS `name`,
       `a`.`sex`            AS `sex`,
       `a`.`birth`          AS `birth`,
       `a`.`vip`            AS `vip`,
       `a`.`identity`       AS `identity`,
       `a`.`phone`          AS `phone`,
       `a`.`date`           AS `date`,
       `a`.`last`           AS `last`,
       ifnull(`c`.`sum`, 0) AS `sum`
from (((select `hospital2`.`patient`.`id`       AS `id`,
               `hospital2`.`patient`.`name`     AS `name`,
               `hospital2`.`patient`.`sex`      AS `sex`,
               `hospital2`.`patient`.`birth`    AS `birth`,
               `hospital2`.`patient`.`vip`      AS `vip`,
               `hospital2`.`patient`.`identity` AS `identity`,
               `hospital2`.`patient`.`phone`    AS `phone`,
               `hospital2`.`patient`.`date`     AS `date`,
               `hospital2`.`patient`.`last`     AS `last`,
               0                                AS `sum`
        from `hospital2`.`patient`)) `a`
       left join (select `b`.`patientid`                                                AS `id`,
                         `b`.`name`                                                     AS `name`,
                         `b`.`sex`                                                      AS `sex`,
                         NULL                                                           AS `birth`,
                         NULL                                                           AS `vip`,
                         NULL                                                           AS `identity`,
                         NULL                                                           AS `phone`,
                         NULL                                                           AS `date`,
                         NULL                                                           AS `last`,
                         sum((((`b`.`card` + `b`.`given`) + `b`.`cash`) + `b`.`other`)) AS `sum`
                  from `hospital2`.`pre_order_view` `b`
                  where (`b`.`state` >= 2)
                  group by `b`.`patientid`) `c` on ((`c`.`id` = `a`.`id`)));

