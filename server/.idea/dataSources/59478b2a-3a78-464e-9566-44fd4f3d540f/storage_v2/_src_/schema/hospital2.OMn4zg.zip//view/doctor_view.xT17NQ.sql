create view doctor_view as
select `hospital2`.`doctor`.`id`       AS `id`,
       `hospital2`.`doctor`.`name`     AS `drname`,
       `hospital2`.`doctor`.`sex`      AS `sex`,
       `hospital2`.`doctor`.`birth`    AS `birth`,
       `hospital2`.`doctor`.`identity` AS `identity`,
       `hospital2`.`doctor`.`phone`    AS `phone`,
       `hospital2`.`doctor`.`address`  AS `address`,
       `hospital2`.`department`.`name` AS `departname`,
       `hospital2`.`doctor`.`useful`   AS `useful`
from (`hospital2`.`doctor`
       join `hospital2`.`department`)
where (`hospital2`.`doctor`.`departmentId` = `hospital2`.`department`.`id`);

