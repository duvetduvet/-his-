create view getandlose_view as
select `stockrecord_view`.`id`           AS `id`,
       `stockrecord_view`.`medicinename` AS `medicinename`,
       `stockrecord_view`.`inprice`      AS `inprice`,
       `stockrecord_view`.`outprice`     AS `outprice`,
       `stockrecord_view`.`feetypename`  AS `feetypename`,
       `stockrecord_view`.`factoryname`  AS `factoryname`,
       `stockrecord_view`.`number`       AS `number`,
       `stockrecord_view`.`usefuldate`   AS `usefuldate`,
       `stockrecord_view`.`positionname` AS `positionname`,
       `stockrecord_view`.`iscount`      AS `iscount`,
       `stockrecord_view`.`date`         AS `date`
from `hospital2`.`stockrecord_view`
where (`stockrecord_view`.`iscount` = 1);

